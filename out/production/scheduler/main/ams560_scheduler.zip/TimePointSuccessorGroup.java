package main;

import java.util.*;

final class TimePointSuccessorGroup {
    private  final Map<TimePoint, Set<TimePoint>> successors;

    private TimePointSuccessorGroup(Map<TimePoint, Set<TimePoint>> successors){
        this.successors = successors;
    }

    final Set<TimePoint> getSuccessors(TimePoint timePoint){
        assert (Objects.nonNull(timePoint)) : "Time point is null";
        return successors.get(timePoint);
    }

    static final TimePointSuccessorGroup create(Set<TimePoint> timePoints){
        // sets the successors by running through the previous time points of the arguments.
        assert (Objects.nonNull(timePoints)) : "Time points are null";
        Map<TimePoint, Set<TimePoint>> successors = new HashMap<>();
        for (TimePoint t : timePoints){
            assert (Objects.nonNull(t)) : "Time point is null";
            successors.put(t, t.previousTimePoints());
        }
        return new TimePointSuccessorGroup(successors);
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        return sb.append("TimePointSuccessorGroup: ").append(System.identityHashCode(this))
                .append("\n").append(successors.toString().indent(4)).toString();
    }
}
