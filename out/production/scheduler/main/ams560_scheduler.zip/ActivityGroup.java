package main;

import java.util.*;

public final class ActivityGroup {
    private Set<TimePoint> timePointList = new HashSet<>();

    public final List<TimePoint> sort(){
        // orders all the time points in the group
        return TimePointSorter.sort(timePointList);
    }

    // todo - use varargs?
    final void addTimePoints(Collection<TimePoint> timePoints){
        assert (Objects.nonNull(timePoints)) : "timePoints is null";
        for (TimePoint t: timePoints) {
            assert (Objects.nonNull(t)) : "TimePoint is null";
            assert (t.isFrozen()) : buildException(SchedulerException.Error.POINT_NOT_FROZEN, t);
            assert (!timePointList.contains(t)) : buildException(SchedulerException.Error.TIME_POINT_EXISTS, t);
            timePointList.add(t);
        }
    }

    private SchedulerException buildException(SchedulerException.Error error, TimePoint t){
        return new SchedulerException.Builder(error)
                .setTimePoint(t)
                .build();
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        String output = sb.append("\n").append(System.identityHashCode(this))
                    .append("\nTimePoints of Activity Group: ").toString();
        if (timePointList.isEmpty())
            return sb.append("\n\tnone").toString();

        for (TimePoint t: timePointList){
            output = sb.append("\n\t").append(t.toSimpleString()).toString();
        }
        return output;
    }


}
